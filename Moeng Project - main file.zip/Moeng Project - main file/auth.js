// auth.js

function signup() {
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;

    if (email && password) {
        localStorage.setItem(email, password);
        alert('Signup successful! Please log in.');
        window.location.href = 'login.html'; // Redirect to login page
    } else {
        alert('Please enter both email and password.');
    }
}

function login() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    const storedPassword = localStorage.getItem(email);

    if (storedPassword && storedPassword === password) {
        alert('Login successful!');
        localStorage.setItem('loggedInUser', email); // Store logged-in user
        window.location.href = 'home.html'; // Redirect to home page
    } else {
        alert('Invalid email or password.');
    }
}

function logout() {
    localStorage.removeItem('loggedInUser'); // Clear logged-in user data
    window.location.href = 'login.html'; // Redirect to login page
}


// Green comment: Script added to handle signup and login functionalities
