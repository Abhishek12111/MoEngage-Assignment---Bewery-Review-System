// Function to get query parameters from URL
function getQueryParams() {
    const queryParams = {};
    window.location.search.slice(1).split('&').forEach(param => {
        const [key, value] = param.split('=');
        queryParams[key] = decodeURIComponent(value);
    });
    return queryParams;
}

// Function to display brewery details
function displayBreweryDetails(breweryData) {
    const breweryDetailsContainer = document.getElementById('breweryDetails');
    // Create a table to display details
    const table = document.createElement('table');
    table.classList.add('table');
    const tbody = document.createElement('tbody');
    // Iterate through brewery data and add rows to the table
    for (const [key, value] of Object.entries(breweryData)) {
        const row = document.createElement('tr');
        const keyCell = document.createElement('th');
        keyCell.scope = 'row';
        keyCell.textContent = key.charAt(0).toUpperCase() + key.slice(1); // Capitalize key
        const valueCell = document.createElement('td');
        valueCell.textContent = value;
        row.appendChild(keyCell);
        row.appendChild(valueCell);
        tbody.appendChild(row);
    }
    table.appendChild(tbody);
    breweryDetailsContainer.appendChild(table);
}

// Function to add a review
function addReview(event) {
    event.preventDefault();
    const ratingInput = document.getElementById('rating').value;
    const reviewInput = document.getElementById('review').value;
    const reviewList = JSON.parse(localStorage.getItem('breweryReviews')) || [];
    const newReview = {
        rating: ratingInput,
        review: reviewInput
    };
    reviewList.push(newReview);
    localStorage.setItem('breweryReviews', JSON.stringify(reviewList));
    // Reload reviews to display newly added review
    loadReviews();
}

// Function to load reviews
function loadReviews() {
    const reviewList = JSON.parse(localStorage.getItem('breweryReviews')) || [];
    const reviewContainer = document.getElementById('reviewContainer');
    // Clear existing reviews
    reviewContainer.innerHTML = '';
    // Iterate through reviews and display them
    reviewList.forEach(review => {
        const reviewItem = document.createElement('div');
        reviewItem.classList.add('card');
        reviewItem.classList.add('mb-2');
        reviewItem.innerHTML = `
            <div class="card-body">
                <h5 class="card-title">Rating: ${review.rating} / 5</h5>
                <p class="card-text">Review: ${review.review}</p>
            </div>
        `;
        reviewContainer.appendChild(reviewItem);
    });
}

// Function to fetch brewery details and display them
function fetchBreweryDetails() {
    const queryParams = getQueryParams();
    // Example: Fetch data from query parameters (replace with actual data source)
    const breweryData = {
        Name: queryParams.name || 'Not available',
        Address: queryParams.address || 'Not available',
        Phone: queryParams.phone || 'Not available',
        Website: queryParams.website || 'Not available',
        Rating: queryParams.rating || 'Not available',
        State: queryParams.state || 'Not available',
        City: queryParams.city || 'Not available',
    };
    displayBreweryDetails(breweryData);
    // Load reviews
    loadReviews();
}

// Call fetchBreweryDetails function when the page loads
document.addEventListener('DOMContentLoaded', fetchBreweryDetails);
