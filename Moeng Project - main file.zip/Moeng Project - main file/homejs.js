

function city(event) {
    event.preventDefault(); // Prevent the default form submission
    const cityInput = document.getElementById('search-city').value;
    const result = document.getElementById('result');
    
    // Clear previous results
    result.innerHTML = '';

    // Call the API using Axios
    axios.get(`https://api.openbrewerydb.org/v1/breweries?by_city=${cityInput}&per_page=3`)
        .then(response => {
            const breweries = response.data;
            
            if (breweries.length === 0) {
                result.innerHTML = '<p>No breweries found.</p>';
            } else {
                const list = document.createElement('ul');
                breweries.forEach(brewery => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `${brewery.name} - ${brewery.brewery_type} - ${brewery.city}, ${brewery.state}`;
                    list.appendChild(listItem);
                });
                result.appendChild(list);
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            result.innerHTML = '<p>Error fetching data. Please try again later.</p>';
        });
}

function searchByName(event) {
    event.preventDefault(); // Prevent the default form submission
    const nameInput = document.getElementById('search-name').value;
    const result = document.getElementById('result');
    
    // Clear previous results
    result.innerHTML = '';

    // Call the API using Axios
    axios.get(`https://api.openbrewerydb.org/v1/breweries?by_name=${nameInput}&per_page=3`)
        .then(response => {
            const breweries = response.data;
            
            if (breweries.length === 0) {
                result.innerHTML = '<p>No breweries found.</p>';
            } else {
                const list = document.createElement('ul');
                breweries.forEach(brewery => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `${brewery.name} - ${brewery.brewery_type} - ${brewery.city}, ${brewery.state}`;
                    list.appendChild(listItem);
                });
                result.appendChild(list);
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            result.innerHTML = '<p>Error fetching data. Please try again later.</p>';
        });
}

function searchByType(event) {
    event.preventDefault(); // Prevent the default form submission
    const typeInput = document.getElementById('search-type').value;
    const result = document.getElementById('result');
    
    // Clear previous results
    result.innerHTML = '';

    // Call the API using Axios
    axios.get(`https://api.openbrewerydb.org/v1/breweries?by_type=${typeInput}&per_page=3`)
        .then(response => {
            const breweries = response.data;
            
            if (breweries.length === 0) {
                result.innerHTML = '<p>No breweries found.</p>';
            } else {
                const list = document.createElement('ul');
                breweries.forEach(brewery => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `${brewery.name} - ${brewery.brewery_type} - ${brewery.city}, ${brewery.state}`;
                    list.appendChild(listItem);
                });
                result.appendChild(list);
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            result.innerHTML = '<p>Error fetching data. Please try again later.</p>';
        });
}



// Function to redirect to brewinfo page with data
function redirectToBrewInfo(breweryData) {
    const url = new URL('brewinfo.html', window.location.href);
    // Pass necessary data as query parameters
    url.searchParams.set('name', breweryData.name);
    url.searchParams.set('address', breweryData.address);
    url.searchParams.set('phone', breweryData.phone);
    url.searchParams.set('website', breweryData.website_url);
    url.searchParams.set('rating', breweryData.rating);
    url.searchParams.set('state', breweryData.state);
    url.searchParams.set('city', breweryData.city);
    window.location.href = url.href;
}

// Function to display search results as list items
function displaySearchResults(breweries) {
    const resultList = document.getElementById('result');
    resultList.innerHTML = ''; // Clear previous results

    breweries.forEach(brewery => {
        const listItem = document.createElement('li');
        listItem.textContent = brewery.name;
        // Add event listener to redirect to brewinfo page with data on click
        listItem.addEventListener('click', () => redirectToBrewInfo(brewery));
        resultList.appendChild(listItem);
    });
}

// Function to handle city search
function city(event) {
    event.preventDefault(); // Prevent the default form submission
    const cityName = document.getElementById('search-city').value;
    // Example API request, replace with your actual API request
    axios.get(`https://api.openbrewerydb.org/breweries?by_city=${cityName}`)
        .then(response => {
            const breweries = response.data;
            displaySearchResults(breweries);
        })
        .catch(error => console.error(error));
}